package com.gem.hami.control;

//个人认证 开通学校模块控制层
public class CertifyControl {
}
