package com.gem.hami.dao;

import com.gem.hami.entity.GoodsCategory;

import java.util.List;

public interface GoodsCategoryMapper {

    public List<GoodsCategory> selectGoodsCategory();

}