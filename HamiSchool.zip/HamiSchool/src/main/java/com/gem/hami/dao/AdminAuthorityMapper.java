package com.gem.hami.dao;


public interface AdminAuthorityMapper {
    public void updateAdminAuthority();

    public void deleteAdminAuthority();

    public void addAdminAuthority();

    public void selectAdminAuthority();

}