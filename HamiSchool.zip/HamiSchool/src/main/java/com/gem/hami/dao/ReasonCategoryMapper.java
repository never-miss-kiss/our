package com.gem.hami.dao;

public interface ReasonCategoryMapper {

}