package com.gem.hami.dao;

public interface ForumPostLikeMapper {


}