package com.gem.hami.control;

public class InitControl {
}
